#!/usr/bin/perl

print <<'END_TESTS';
1..1
ok 1 - source.pl
END_TESTS
